-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.10.2-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.5.0.6677
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table teladanpeg.jabatan
CREATE TABLE IF NOT EXISTS `jabatan` (
  `id_jabatan` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `jabatan` varchar(100) NOT NULL,
  `status` enum('JST','JFT','JFU') NOT NULL DEFAULT 'JFU',
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_general_ci;

-- Dumping data for table teladanpeg.jabatan: ~43 rows (approximately)
INSERT INTO `jabatan` (`id_jabatan`, `jabatan`, `status`) VALUES
	(1, 'Kepala Bidang Informasi Kepegawaian', 'JST'),
	(2, 'Pranata Komputer', 'JFT'),
	(3, 'Analis Kepegawaian', 'JFT'),
	(4, 'Arsiparis', 'JFT'),
	(5, 'Analis Data dan Informasi', 'JFU'),
	(6, 'Pengelola Sistem dan Jaringan', 'JFU'),
	(7, 'Pranata Kearsipan', 'JFU'),
	(8, 'Analis Sistem Informasi dan Jaringan', 'JFU'),
	(22, 'Kepala Bidang Pengembangan dan Supervisi Kepegawaian', 'JST'),
	(23, 'Auditor Kepegawaian', 'JFT'),
	(24, 'Assesor SDM Aparatur', 'JFT'),
	(25, 'Analis Kinerja', 'JFU'),
	(26, 'Auditor Manajemen Aparatur Sipil Negara', 'JFT'),
	(27, 'Perancang Peraturan Perundang-undangan', 'JFT'),
	(28, 'Kepala Bidang Mutasi dan Status Kepegawaian', 'JST'),
	(29, 'Analis Hukum', 'JFU'),
	(30, 'Pengolah Data', 'JFU'),
	(31, 'Pengadministrasi Kepegawaian', 'JFU'),
	(32, 'Pengelola Data', 'JFU'),
	(33, 'Analis SDM Aparatur', 'JFT'),
	(34, 'Kepala Bidang Pengangkatan dan Pensiun', 'JST'),
	(35, 'Kepala Subbagian Kepegawaian dan Kinerja', 'JST'),
	(36, 'Perawat', 'JFT'),
	(37, 'Petugas Protokol', 'JFU'),
	(38, 'Analis Pengembangan SDM Aparatur', 'JFU'),
	(39, 'Kepala Subbagian Keuangan', 'JST'),
	(40, 'Kepala Subbagian Umum', 'JST'),
	(41, 'Bendahara', 'JFU'),
	(42, 'Analis Keuangan', 'JFU'),
	(43, 'Analis Monev dan Pelaporan', 'JFU'),
	(44, 'Analis Peng Keu APBN', 'JFT'),
	(45, 'Analis Perencanaan', 'JFU'),
	(46, 'Pengelola Keuangan', 'JFU'),
	(47, 'Analis BMN', 'JFU'),
	(48, 'Pengelola Barang Milik Negara', 'JFU'),
	(49, 'Pranata Humas', 'JFT'),
	(50, 'Pengelola Pengadaan Barang Jasa', 'JFT'),
	(51, 'Pengelola Kendaraan', 'JFU'),
	(52, 'Teknisi Peralatan, Listrik dan Elektronika', 'JFU'),
	(53, 'Pengelola Kepegawaian', 'JFU'),
	(54, 'Kepala UPT BKN Semarang', 'JST'),
	(55, 'Analis Permasalahan Hukum', 'JFU'),
	(56, 'Kepala Bagian Tata Usaha', 'JST');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
