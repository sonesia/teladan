<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\PegawaiModel;

class PegawaiController extends BaseController
{
    public function index()
    {
        $pegawai = new PegawaiModel();
        $data = [
            'pegawai' => $pegawai->findAll(),
            'title' => 'Data Pegawai'
        ];
        // $data = [
        //     'title' => 'Data Pegawai'
        // ];

        // dd($tampil['pegawai']);

        return view('admin/pegawai/index', $data);
    }
}
