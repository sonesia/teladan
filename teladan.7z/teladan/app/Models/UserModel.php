<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    public function get_data($user, $password)
    {
        return $this->db->table('pengguna')
            ->where(array('nama_pengguna' => $user, 'kata_kunci' => $password))
            ->get()->getRowArray();
    }

    //--------------------------------------------------------------------

}
