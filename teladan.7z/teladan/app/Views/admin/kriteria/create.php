<?= $this->extend('admin/layout/template') ?>

<?= $this->Section('content') ?>
<div id="layoutSidenav_content">
    <main>
        <div class="container-fluid px-4">
            <h1 class="mt-4">Tambah Data Kriteria</h1>
            <!-- <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Dashboard</li>
            </ol> -->
            <div class="card mb-4">
                <div class="card-header">
                    <i class="fas fa-table me-1"></i>
                    Kriteria Pegawai Teladan
                </div>
                <form action="<?php echo base_url() . "KriteriaController/tambah_aksi"; ?>" method="post">
                    <table style="margin:20px auto;">
                        <tr>
                            <td>Nama</td>
                            <td><input type="text" name="nama"></td>
                        </tr>
                        <tr>
                            <td>Sifat</td>
                            <td>
                                <select name="sifat">
                                    <option value="min"> Min </option>
                                    <option value="max"> Max </option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <td></td>
                            <td><input type="submit" name="submit" value="Tambah"></td>
                        </tr>
                    </table>
                </form>
            </div>
        </div>
    </main>
    <?= $this->endSection() ?>