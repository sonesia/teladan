<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\KriteriaModel;

class KriteriaController extends BaseController
{
    public function index()
    {
        $kriteria = new KriteriaModel();
        $data = [
            'kriteria' => $kriteria->findAll(),
            'title' => 'Kriteria'
        ];
        // dd($data['kriteria']);
        // $data = [
        //     'title' => 'Data Pegawai'
        // ];

        // dd($tampil['pegawai']);

        return view('admin/kriteria/index', $data);
    }

    public function __construct()
    {
        // parent::__construct();
        $this->kriteriaModel = new KriteriaModel();
        //$this->pegawaiModel = new PegawaiModel();
        $this->tipe_user = $_SESSION['tipe_user'];
        // $this->load->model('KriteriaModel');
        // $this->load->helper(array('url'));
    }

    /**===========================================================*/
    /** Fungsi CREATE */

    public function tambah()
    {
        $this->load->view('kriteria\create');
    }

    public function tambah_aksi()
    {
        $nama = $this->input->post('id_kriteria');
        $jenis_kelamin = $this->input->post('nama');
        $alamat = $this->input->post('sifat');

        $data = array(
            'id_kriteria' => $id,
            'nama' => $nama,
            'sifat' => $sifat,
        );
        $this->KriteriaModel->input_data($data, 'kriteria');
        redirect('KriteriaController/index');
    }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi READ */

    // public function index()
    // {
    //     $data['kriteria'] = $this->KriteriaModel->tampil_data()->result();
    //     $this->load->view('view', $data);
    // }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi UPDATE */

    public function edit($id)
    {
        $where = array('id_kriteria' => $id);
        $data['kriteria'] = $this->KriteriaModel->edit_data($where, 'kriteria')->result();
        $this->load->view('kriteria\edit', $data);
    }

    public function update()
    {
        $id = $this->input->post('id_kriteria');
        $nama = $this->input->post('nama');
        $sifat = $this->input->post('sifat');

        $data = array(
            'id_kriteria' => $id,
            'nama' => $nama,
            'sifat' => $sifat,
        );

        $where = array(
            'id_kriteria' => $id
        );

        $this->KriteriaModel->update_data($where, $data, 'kriteria');
        redirect('KriteriaController/index');
    }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi DELETE */

    public function hapus($id)
    {
        $where = array('id_kriteria' => $id);
        $this->KriteriaModel->hapus_data($where, 'kriteria');
        redirect('KriteriaController/index');
    }
}
