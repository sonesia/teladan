<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\ModalModel;

class ModelController extends BaseController
{
	public function index()
	{
		// buat object model $model
		$model = new ModalModel();
		// $data['all_model'] = $model->findAll();
		// $data['title'] = 'Model';

		$data = [
			'all_model' => $model->findAll(),
			'title' => 'Model'
		];
		/*
     siapkan data untuk dikirim ke view dengan nama $newses
     dan isi datanya dengan news yang sudah terbit
    */
		//$data['modals'] = $modal->where('bobot', 'published')->findAll();
		//dd($data);
		// kirim data ke view
		return view('admin/model/index', $data);
	}

	//------------------------------------------------------------
	public function add_modal()
	{
		return view('add_model');
	}
}
