<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;

class PenilaianController extends BaseController
{
    public function index()
    {
        //
    }
}
