<?php

namespace App\Controllers\User;

use App\Controllers\BaseController;
use App\Models\UserModel;

class Login extends BaseController
{
    public function index()
    {
        return view('user/user_form');
    }

    public function login_action()
    {
        $muser = new UserModel();

        $user = $this->request->getPost('user');
        $password = $this->request->getPost('password');

        $cek = $muser->get_data($user, $password);

        if (($cek['nama_pengguna'] == $user) && ($cek['kata_kunci'] == $password)) {
            session()->set('nama_pengguna', $cek['nama_pengguna']);
            session()->set('id_pns', $cek['id_pns']);
            session()->set('tipe_user', $cek['tipe_user']);
            return redirect()->to(base_url('dashboard'));
        } else {
            session()->setFlashdata('gagal', 'Username / Password salah');
            return redirect()->to(base_url('login'));
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to(base_url('login'));
    }

    //--------------------------------------------------------------------

}
