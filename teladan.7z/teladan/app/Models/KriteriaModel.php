<?php

namespace App\Models;

use CodeIgniter\Model;

class KriteriaModel extends Model
{
    protected $table            = 'kriteria';
    protected $primaryKey       = 'id_kriteria';
    protected $useAutoIncrement = true;
    protected $returnType       = 'object';
    // protected $useSoftDeletes   = false;
    // protected $protectFields    = true;
    protected $allowedFields    = ['id_kriteria', 'nama', 'sifat'];

    /** Fungsi CREATE */

    public function input_data($data, $table)
    {
        $this->db->insert($table, $data);
    }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi READ */

    public function tampil_data()
    {
        return $this->db->get('kriteria');
    }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi UPDATE */

    public function edit_data($where, $table)
    {
        return $this->db->get_where($table, $where);
    }

    public  function update_data($where, $data, $table)
    {
        $this->db->where($where);
        $this->db->update($table, $data);
    }
    /**===========================================================*/

    /**===========================================================*/
    /** Fungsi DELETE */

    public  function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
    /**===========================================================*/
}
